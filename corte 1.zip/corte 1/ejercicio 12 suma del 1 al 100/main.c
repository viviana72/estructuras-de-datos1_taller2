#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1=0, n2=0, suma, i;
    printf("suma de los numeros del 1 al 100\n");
    while(n2<=100){
    n1=n1+n2;
    n2=n2+1;
    suma=n1;

    }
     printf("la suma es: %d\n",suma);

    return 0;
}
