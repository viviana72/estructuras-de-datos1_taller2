#include <stdio.h>
#include <stdlib.h>

int main()
{
    int horasD, horasNo, horasDo, horasF, salario, numeroHoras, porcHorasN, porcHorasDo, porcHorasFes, valorHora=2500, horaDiurna;
    printf("ingrese el numero de horas diurnas laboradas\n");
    scanf("%d",&horasD);
    printf("ingrese el numero de horas noturnas laboradas\n");
    scanf("%d",&horasNo);
    printf(" ingrese el numero de las horas domonicales laboradas\n");
    scanf("%d",&horasDo);
    printf("ingrese el numero de las horas festivos laboradas\n");
    scanf("%d",&horasF);
    horasD=valorHora*horasD;
    porcHorasN=2500*0.35;
    porcHorasDo=2500*0.50;
    porcentajeHorasFes=2500*0.75;
    horasDiurnas=2500*numeroHoras;
    horasNoturnas=(2500+porcentajeHorasN)*numeroHoras;
    horasDominicales=(2500+porcentajeHorasDo)*numeroHoras;
    horasFestivos=(2500+porcentajeHorasFes)*numeroHoras;
    salario=horasDiurnas+horasNoturnas+horasDominicales+horasFestivos;
    printf("el valor de las horas noturnas es: %d\n"),horasNoturnas;
    printf("el valor de las horas dominicales es: %d\n"),horasDominicales;
    printf("el valor de las horas festivos es: %d\n"),horasFestivos;
    salario=horasDiurnas+horasNoturnas+horasDominicales+horasFestivos;
    printf("su salario es: %d\n", salario);

    return 0;
}
