#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num, i,tabla,resultado;

    printf("ingrese un numero a multiplicar\n");
    scanf("%d",&num);
    for(i=1;i<=10;i++)
        printf("%d*%d = %d \n",tabla,i,resultado);
    return 0;
}
