#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1, num2, num3, num4;
    printf("ingrese tres numeros\n");
    scanf("%d",&num1);
    scanf("%d",&num2);
    scanf("%d",&num3);
    printf("ingrese un cuarto numero\n");
    scanf("%d",&num4);
    if(num1==num4){
        printf("el numero si coincide\n");
    }else{
        if(num2==num4){
            printf("el numero si coincide\n");
        }else{
            if(num3==num4){
                printf("el numero si coincide\n");
            }else{
                printf("el numero no coincide\n");
            }
        }
    }

    return 0;
}
