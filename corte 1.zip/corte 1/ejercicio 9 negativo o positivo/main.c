#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num;
    printf("ingrese un numero\n");
    scanf("%d",&num);
    if(num>0){
        printf("el numero es positivo");
    }else{
        printf("el numero es negativo");

    }
    return 0;
}
