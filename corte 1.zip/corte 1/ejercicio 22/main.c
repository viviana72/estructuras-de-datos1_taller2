#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,suma=0;

    printf("ingrese un numero\n");
    scanf("%d",&n);

    for(int i=1; i<=n; i++){
        suma+=i;

    }
    printf("la suma es: %d\n",suma);

    return 0;
}
