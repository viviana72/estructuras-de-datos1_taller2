#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("ingrese el numero a multiplicar \n");
    int tabla, i, resultado;
    scanf("%d",&tabla);
    i=1;
    do{
            resultado=tabla*i;
            printf("%d*%d = %d\n",tabla, i, resultado);
            i+=1;
    }while (i<=10);

    return 0;
}
