#include <stdio.h>
#include <stdlib.h>

main()
{
int i,total,contador;
contador=1;
total=1;
printf("ingrese un numero para el factorial: ");
scanf("%d",&i);
while(contador<=i)
{
 total = total * contador;
 contador++;
}
 printf("El factorial de %d es: %d",i,total);


return 0;

}
