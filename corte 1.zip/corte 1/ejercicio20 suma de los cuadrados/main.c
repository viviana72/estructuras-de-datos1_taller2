#include <stdio.h>
#include <stdlib.h>

int main()
{
    int suma=0, cuadrado;

    for(int i=1; i<=10; i++){
        cuadrado=i*i;
        suma+=cuadrado;
    }

    printf("el resultado de la suma es: %d\n",suma);
    return 0;
}
