#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=1, suma=0;
    while(i<=50){
        if(i%2==1){
            suma=suma+i;
        }
        i++;
    }

    printf("la suma de los numeros impares es: %d\n", suma);

    return 0;
}
