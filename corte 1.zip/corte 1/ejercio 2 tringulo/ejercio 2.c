#include <stdio.h>
#include <math.h>

int main()
{
    int base,altura,area=0;
    printf("ingrese la bese del triangulo\n");
    scanf("%d",&base);
    printf("ingrese la altura del triangulo\n");
    scanf("%d",&altura);
    area=base*altura/2
    printf("la base del triangulo es: %d \n",area);

    return 0;
}
