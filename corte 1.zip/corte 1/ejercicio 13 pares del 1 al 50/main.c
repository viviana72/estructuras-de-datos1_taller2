#include <stdio.h>
#include <stdlib.h>

int main()
{
    int suma=0, i;
    i=1;
    while(i<=50){
        if(i%2==0){
            suma=suma+1;
        }
        i++;
    }
    printf("la suma de los numeros pares es: %d\n",suma);
    return 0;
}
