#include <stdio.h>
#include <stdlib.h>

int main()
{
    int suma=0, elevacion=0, num;
    printf("ingrese un numero\n");
    scanf("%d",&num);

    for(int i=1;i<=num;i++){
        elevacion= pow(2,i);
        suma+=elevacion;
    }
    printf("el valor total es: %d\n", suma);

    return 0;
}
