#include <stdio.h>
#include <stdlib.h>

int main()
{
    int contador;
    printf("este es un programa que muestra los numeros del 1 al 10 \n");
    contador=1;
    while(contador<=10){
        printf("%d \n",contador);
        contador++;
    }
    return 0;
}
