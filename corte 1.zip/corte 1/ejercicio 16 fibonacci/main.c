#include <stdio.h>
#include <stdlib.h>

int main()
{
   int s,a=0,b=1,i=1, n;
   printf("ingrese un numero para hacer la serie fibonacci ");
   scanf("%d",&n);

	while(i<=n){

		s=a+b;
		printf("s %d",s);

		a=b;

		b=s;

		i++;

	}


       return 0;
}
