#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num;
    printf("ingrese un numero entero\n");
    scanf("%d",&num);
    if(num%2==0){
        printf("es un numero par: %d\n", num);
    }else{
        printf("es un numero impar: %d\n",num);
    }

    return 0;
}
