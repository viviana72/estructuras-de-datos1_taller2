#include <stdlib.h>
#include <math.h>
int main()
{
    int radio, longitud=0, area=0, diametro=0;
    printf("ingrese el radio de la circuferencia ");
    scanf("%d",&radio);
    area=M_PI*pow(radio,2);
    diametro=2*M_PI*radio;
    longitud=2*radio;
    printf("el area es: %d \n",area);
    printf("el diametro es: %d \n",diametro);
    printf("la longitud es: %d \n",longitud);

    return 0;
}
