#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    printf("ingrese dos numeros\n");
    scanf("%d",&a);
    scanf("%d",&b);
    if (a>b){
            printf("el numero mayor es: %d\n",a);
    }else{
        printf("el numero mayor es: %d\n",b);
    }
    return 0;
}
